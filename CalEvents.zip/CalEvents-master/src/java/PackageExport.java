


public class PackageExport{
		
	private String users;
	private String age;

    /**
     * @return the users
     */
    public String getUsers() {
        return users;
    }

    /**
     * @param users the users to set
     */
    public void setUsers(String users) {
        this.users = users;
    }

    /**
     * @return the age
     */
    public String getAge() {
        return age;
    }

    /**
     * @param age the age to set
     */
    public void setAge(String age) {
        this.age = age;
    }
	
	
	
	
	
		
}
