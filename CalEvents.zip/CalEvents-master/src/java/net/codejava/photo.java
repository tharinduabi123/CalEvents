package net.codejava;

import java.util.HashSet;
import java.util.Set;

public class photo {
    private String photo_id;
    private String album_id;
    private String photo_name;
    private String base64Photo_type;
    
    public String getBase64Photo_type(){
        return base64Photo_type;
    }
    public void setBase64Photo_type(String base64Photo_type){
        this.base64Photo_type = base64Photo_type;
    }

    void setphoto_id(String photo_id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setalbum_id(String album_id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void setphoto_name(String photo_name) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
